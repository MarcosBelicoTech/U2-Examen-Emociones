package com.example.examenu2.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.examenu2.R;
import com.example.examenu2.db.DatabaseHelper;
import com.example.examenu2.model.MoodEntry;

public class RegisterFragment extends Fragment {

    private RatingBar ratingBarMood;
    private EditText editTextActivities;
    private EditText editTextNotes;
    private Button buttonSave;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflar el layout para este fragmento
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // Inicializar la base de datos
        dbHelper = new DatabaseHelper(getContext());

        // Vincular vistas
        ratingBarMood = view.findViewById(R.id.ratingBarMood);
        editTextActivities = view.findViewById(R.id.editTextActivities);
        editTextNotes = view.findViewById(R.id.editTextNotes);
        buttonSave = view.findViewById(R.id.buttonSave);

        // Configurar el listener del botón
        buttonSave.setOnClickListener(v -> saveMoodEntry());

        return view;
    }

    private void saveMoodEntry() {
        // Obtener datos de la UI
        float rating = ratingBarMood.getRating();
        String activities = editTextActivities.getText().toString().trim();
        String notes = editTextNotes.getText().toString().trim();
        long timestamp = System.currentTimeMillis();

        if (rating == 0) {
            Toast.makeText(getContext(), "Por favor, selecciona una calificación", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear objeto MoodEntry y guardarlo
        MoodEntry entry = new MoodEntry(timestamp, rating, activities, notes);
        long id = dbHelper.addMoodEntry(entry);

        if (id != -1) {
            Toast.makeText(getContext(), "¡Registro guardado!", Toast.LENGTH_SHORT).show();
            // Limpiar campos
            ratingBarMood.setRating(3); // Reset a neutral
            editTextActivities.setText("");
            editTextNotes.setText("");
        } else {
            Toast.makeText(getContext(), "Error al guardar el registro", Toast.LENGTH_SHORT).show();
        }
    }
}