package com.example.examenu2.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.examenu2.R;
import com.example.examenu2.db.DatabaseHelper;
import com.example.examenu2.model.MoodEntry;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class AnalysisFragment extends Fragment {

    private PieChart pieChart;
    private BarChart barChart;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_analysis, container, false);

        pieChart = view.findViewById(R.id.pieChart);
        barChart = view.findViewById(R.id.barChart);
        dbHelper = new DatabaseHelper(getContext());

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Recargar datos cada vez que la pestaña se vuelve visible
        loadChartData();
    }

    private void loadChartData() {
        List<MoodEntry> entries = dbHelper.getAllMoodEntries();
        if (entries.isEmpty()) {
            pieChart.clear();
            barChart.clear();
            // Aquí podrías mostrar un texto de "No hay datos"
            return;
        }

        loadPieChart(entries);
        loadBarChart(entries);
    }

    private void loadPieChart(List<MoodEntry> entries) {
        // Contar categorías de ánimo
        int countLow = 0; // 1-2.4 estrellas
        int countNeutral = 0; // 2.5-3.5 estrellas
        int countHigh = 0; // 3.6-5 estrellas

        for (MoodEntry entry : entries) {
            if (entry.getMoodRating() < 2.5) {
                countLow++;
            } else if (entry.getMoodRating() <= 3.5) {
                countNeutral++;
            } else {
                countHigh++;
            }
        }

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        if (countLow > 0) pieEntries.add(new PieEntry(countLow, "Bajo"));
        if (countNeutral > 0) pieEntries.add(new PieEntry(countNeutral, "Neutral"));
        if (countHigh > 0) pieEntries.add(new PieEntry(countHigh, "Alto"));

        PieDataSet dataSet = new PieDataSet(pieEntries, "Distribución de Ánimo");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(16f);

        PieData pieData = new PieData(dataSet);
        pieChart.setData(pieData);
        pieChart.getDescription().setEnabled(false);
        pieChart.setCenterText("Ánimo");
        pieChart.animateY(1000);
        pieChart.invalidate(); // Refrescar
    }

    private void loadBarChart(List<MoodEntry> entries) {
        // --- Promedio por día (últimos 7 días) ---
        // Esto es más complejo, agrupamos por día
        Map<Long, List<Float>> ratingsByDay = new HashMap<>();
        long sevenDaysAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7);

        // Agrupar calificaciones por día
        for (MoodEntry entry : entries) {
            if (entry.getTimestamp() >= sevenDaysAgo) {
                // Obtenemos el día (truncando la hora)
                long dayTimestamp = entry.getTimestamp() / TimeUnit.DAYS.toMillis(1);

                if (!ratingsByDay.containsKey(dayTimestamp)) {
                    ratingsByDay.put(dayTimestamp, new ArrayList<>());
                }
                ratingsByDay.get(dayTimestamp).add(entry.getMoodRating());
            }
        }

        ArrayList<BarEntry> barEntries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM", Locale.getDefault());

        int i = 0;
        // Calcular promedio por día
        // Ordenar las keys (días) sería ideal, pero para este ejemplo las usamos como vienen
        for (Map.Entry<Long, List<Float>> mapEntry : ratingsByDay.entrySet()) {
            float sum = 0;
            for (float rating : mapEntry.getValue()) {
                sum += rating;
            }
            float avg = sum / mapEntry.getValue().size();

            barEntries.add(new BarEntry(i, avg));
            labels.add(sdf.format(new Date(mapEntry.getKey() * TimeUnit.DAYS.toMillis(1))));
            i++;
        }

        if (barEntries.isEmpty()) {
            barChart.clear();
            return;
        }

        BarDataSet dataSet = new BarDataSet(barEntries, "Promedio de Ánimo (Últ. 7 días)");
        dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(12f);

        BarData barData = new BarData(dataSet);
        barChart.setData(barData);

        // Formatear eje X (días) - Opcional pero recomendado
        // XAxis xAxis = barChart.getXAxis();
        // xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        // xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        // xAxis.setGranularity(1f);
        // xAxis.setGranularityEnabled(true);

        barChart.getDescription().setEnabled(false);
        barChart.animateY(1000);
        barChart.invalidate(); // Refrescar
    }
}