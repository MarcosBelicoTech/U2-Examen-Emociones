package com.example.examenu2.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.examenu2.model.MoodEntry;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "moodtracker.db";
    private static final int DATABASE_VERSION = 1;

    // Tabla y Columnas
    public static final String TABLE_MOOD = "mood_entries";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TIMESTAMP = "timestamp";
    public static final String COLUMN_RATING = "rating";
    public static final String COLUMN_ACTIVITIES = "activities";
    public static final String COLUMN_NOTES = "notes";

    // SQL para crear la tabla
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_MOOD + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TIMESTAMP + " INTEGER NOT NULL, " +
                    COLUMN_RATING + " REAL NOT NULL, " +
                    COLUMN_ACTIVITIES + " TEXT, " +
                    COLUMN_NOTES + " TEXT" +
                    ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOOD);
        onCreate(db);
    }

    // --- Métodos CRUD ---

    // Añadir una nueva entrada
    public long addMoodEntry(MoodEntry entry) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TIMESTAMP, entry.getTimestamp());
        values.put(COLUMN_RATING, entry.getMoodRating());
        values.put(COLUMN_ACTIVITIES, entry.getActivities());
        values.put(COLUMN_NOTES, entry.getNotes());

        long id = db.insert(TABLE_MOOD, null, values);
        db.close();
        return id;
    }

    // Obtener todas las entradas
    public List<MoodEntry> getAllMoodEntries() {
        List<MoodEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MOOD + " ORDER BY " + COLUMN_TIMESTAMP + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID));
                long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));
                float rating = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_RATING));
                String activities = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ACTIVITIES));
                String notes = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOTES));
                entries.add(new MoodEntry(id, timestamp, rating, activities, notes));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return entries;
    }

    // Obtener la entrada más reciente (para la notificación)
    public MoodEntry getLatestMoodEntry() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MOOD + " ORDER BY " + COLUMN_TIMESTAMP + " DESC LIMIT 1", null);

        MoodEntry entry = null;
        if (cursor.moveToFirst()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID));
            long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));
            float rating = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_RATING));
            String activities = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ACTIVITIES));
            String notes = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOTES));
            entry = new MoodEntry(id, timestamp, rating, activities, notes);
        }
        cursor.close();
        db.close();
        return entry;
    }
}