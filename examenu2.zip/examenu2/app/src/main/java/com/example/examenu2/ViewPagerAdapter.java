package com.example.examenu2.ui;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentStateAdapter {

    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // Devuelve el fragmento correspondiente a la posición
        switch (position) {
            case 0:
                return new RegisterFragment();
            case 1:
                return new AnalysisFragment();
            default:
                return new RegisterFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 2; // Tenemos 2 pestañas
    }
}