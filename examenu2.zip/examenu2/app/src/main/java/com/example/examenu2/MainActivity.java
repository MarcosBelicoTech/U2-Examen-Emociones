package com.example.examenu2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

// Importar la clase de ViewBinding generada automáticamente
import com.example.examenu2.databinding.ActivityMainBinding;

import com.example.examenu2.receiver.NotificationReceiver;
import com.example.examenu2.ui.ViewPagerAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    // Variable para ViewBinding
    private ActivityMainBinding binding;

    // Launcher para pedir permiso de notificación
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permiso concedido, podemos programar la alarma
                    scheduleNotificationAlarm();
                } else {
                    // El usuario negó el permiso.
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // --- ESTA ES LA CORRECCIÓN ---
        // 1. Inflar la vista usando ViewBinding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        // 2. Establecer la vista raíz (root) de ViewBinding
        setContentView(binding.getRoot());
        // --- FIN DE LA CORRECCIÓN ---


        // Ahora, accedemos a las vistas a través de la variable 'binding'
        ViewPagerAdapter adapter = new ViewPagerAdapter(this);
        binding.viewPager.setAdapter(adapter);

        // Conectar el TabLayout con el ViewPager2
        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {
            if (position == 0) {
                tab.setText("Registrar");
                // TODO: Puedes cambiar este icono si añades uno a res/drawable
                // tab.setIcon(R.drawable.ic_edit);
            } else {
                tab.setText("Análisis");
                // TODO: Puedes cambiar este icono si añades uno a res/drawable
                // tab.setIcon(R.drawable.ic_chart);
            }
        }).attach();

        // Pedir permisos y programar alarma
        checkPermissionsAndScheduleAlarm();
    }

    private void checkPermissionsAndScheduleAlarm() {
        // 1. Comprobar permiso de notificación (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                // Permiso ya concedido
                scheduleNotificationAlarm();
            } else {
                // Pedir permiso
                requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
            }
        } else {
            // Versiones anteriores a Android 13 no necesitan permiso en tiempo de ejecución
            scheduleNotificationAlarm();
        }
    }

    private void scheduleNotificationAlarm() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, NotificationReceiver.class);

        // Es importante usar FLAG_IMMUTABLE o FLAG_MUTABLE
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        // Para la demo en clase (se repite cada 1 minuto):
        long demoInterval = 60 * 1000;
        long triggerTime = System.currentTimeMillis() + demoInterval;

        // Comprobar si se puede programar alarmas exactas
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, demoInterval, pendingIntent);
            } else {
                // Opcional: Redirigir al usuario a configuración
            }
        } else {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, demoInterval, pendingIntent);
        }
    }
}