package com.example.examenu2.model;

public class MoodEntry {
    private long id;
    private long timestamp; // Fecha y hora en milisegundos
    private float moodRating; // Calificación (ej. 1 a 5)
    private String activities; // "Correr, Leer, Amigos"
    private String notes; // "Fue un buen día"

    // Constructor vacío
    public MoodEntry() {
    }

    // Constructor completo
    public MoodEntry(long id, long timestamp, float moodRating, String activities, String notes) {
        this.id = id;
        this.timestamp = timestamp;
        this.moodRating = moodRating;
        this.activities = activities;
        this.notes = notes;
    }

    // Constructor sin ID (para crear nuevos)
    public MoodEntry(long timestamp, float moodRating, String activities, String notes) {
        this.timestamp = timestamp;
        this.moodRating = moodRating;
        this.activities = activities;
        this.notes = notes;
    }

    // --- Getters y Setters ---
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public float getMoodRating() { return moodRating; }
    public void setMoodRating(float moodRating) { this.moodRating = moodRating; }
    public String getActivities() { return activities; }
    public void setActivities(String activities) { this.activities = activities; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}