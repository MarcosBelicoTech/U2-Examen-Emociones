package com.example.examenu2.receiver;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.examenu2.MainActivity;
import com.example.examenu2.R;
import com.example.examenu2.db.DatabaseHelper;
import com.example.examenu2.model.MoodEntry;

import java.util.concurrent.TimeUnit;

public class NotificationReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "mood_reminder_channel";
    private static final int NOTIFICATION_ID = 101;

    // TODO: Cambia este valor por (18 * 60 * 60 * 1000) para 18 horas
    // Para la demostración en clase (ej. 1 minuto):
    private static final long DEMO_INTERVAL_MS = 60 * 1000; // 1 Minuto

    @Override
    public void onReceive(Context context, Intent intent) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        MoodEntry lastEntry = dbHelper.getLatestMoodEntry();

        long timeSinceLastEntry = System.currentTimeMillis(); // Hora actual
        if (lastEntry != null) {
            timeSinceLastEntry = System.currentTimeMillis() - lastEntry.getTimestamp();
        }

        // Comprobar si ha pasado más tiempo del intervalo
        if (timeSinceLastEntry > DEMO_INTERVAL_MS) {
            sendNotification(context);
        }
    }

    private void sendNotification(Context context) {
        createNotificationChannel(context);

        // Intent para abrir la app al hacer clic en la notificación
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher) // Asegúrate de tener este icono
                .setContentTitle("Registro de Ánimo")
                .setContentText("¡No olvides registrar cómo te sientes hoy!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true); // La notificación desaparece al tocarla

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        // Comprobar permiso antes de notificar
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Si no hay permiso, la notificación no se enviará.
            // El permiso debe pedirse en MainActivity.
            return;
        }
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    // Crear el Canal de Notificación (necesario para Android 8.0+)
    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Recordatorio de Ánimo";
            String description = "Canal para recordar al usuario que registre su ánimo";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}