pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    // ESTA ES LA CORRECCIÓN:
    // Define las versiones de los plugins que tu proyecto usará.
    plugins {
        id("com.android.application") version "8.2.0" apply false
        id("org.jetbrains.kotlin.android") version "1.9.20" apply false
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Repositorio para MPAndroidChart
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "examenu2"
include(":app")